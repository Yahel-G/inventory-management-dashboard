import Image from "next/image";
import Dashboard from "@/app/dashboard/page";

export default function Home() {
  return (
    <Dashboard />
  );
}
